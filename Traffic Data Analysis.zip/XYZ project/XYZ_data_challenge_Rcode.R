############################################################################
############## Part 1. Exploratory Data Analysis  ##########################
############################################################################
#install.packages("rjson")
library(rjson)
setwd("C:/Users/Ashwini/Desktop/XYZ") #the working directory
log1=fromJSON(file="logins.json")
head(log1$login_time)
length((log1$login_time))
a11=log1$login_time;
b12=as.POSIXct(a11,format="%Y-%m-%d %H:%M:%S",tz="US/Pacific")
b11=sort(b12);
# to find a day
weekdays.POSIXt(b11[1])
head(as.numeric(b11))
t12=as.numeric(b11)-8*3600; # by default R takes London Time which is 8 hours ahead of PST
t11=t12[2:length(t12)]-t12[1]+736 # by adding 736, we count from 8pm rather than 8:12pm
# aggregate the data in 15 min time zone 15 min=15*60=900 sec
en=t11[length(t11)];freq=numeric(0);
st=900;i=1;
while(st<en)
{
  if(i==1)
    {
      freq[i]=min(which(t11>st));st=st+900;
    }  else
    {
      freq[i]=min(which(t11>st))-sum(freq[1:(i-1)]);
      st=st+900;
    }
  i=i+1
}
ti=1:length(freq)

####################################
########## Figure 1.1 ##############
####################################
# The login counts time series plot aggergated over 15 minute time interval

plot(ti,freq,type="l",main="Time Series Plot of Login Counts",xlab="Time Index: each index represents 15 minutes interval",ylab="Frequency")

# weekly count plot, starts from Sunday, mid-night, from Thursday 8pm, till Sunday 12:00 mid night, 304 counts of 15 min
n.freq=freq[305:length(freq)];
# to add the previous data, find the Thu 8pm, starting Sunday mid night 368 counts
p.freq=freq[1:304];
# create the week freq data, 672, 15 min interval in a week
#id.mon=min(which(weekdays(b11)=="Monday"))
#b11[id.mon]
w.freq=numeric(0)
w.ti=1:672;ll=numeric(0)
for(k in 1:672)
{
  id1=seq(k,length(n.freq),672)
  w.freq[k]=mean(n.freq[id1]);ll[k]=length(id1);
}

# now add the p.freq
for(j in 1:304)
{
st=368+j;  
w.freq[st]=(ll[st]*w.freq[st]+p.freq[j])/(ll[st]+1)
}
# note: w.freq is averaged over number of weeks
# all data plot

#############################################
############# Figure 1.2 ####################
#############################################

plot(w.ti,xaxt="n",w.freq,type="l",main="Time Series Plot of Login Counts (over a week)",xlab="Time Index: starts from SUN midnight till next SUN before midnight (15 minutes interval)",ylab="Frequency: Averaged over # of weeks")
axis(1, xaxp=c(0, 672, 7), las=2)#dev.off()

########################################################################################################################
##### The below code gives a plot similar to Figure 1.4 but for login counts aggregated over 15 min. ###################
########################################################################################################################

# next, daily logins by 15 min interval, a matrix of 96 by 7
d.freq=matrix(0,nrow=96,ncol=7)
colnames(d.freq)=c("Mon","Tue","Wed","Thu","Fri","Sat","Sun")
row.lab=format( seq.POSIXt(as.POSIXct(Sys.Date()), as.POSIXct(Sys.Date()+1), by = "15 min"),"%H:%M",tz="GMT")
row.lab=row.lab[-1];
row.names(d.freq)=row.lab;
row.names(d.freq)[49]=c("Noon");
row.names(d.freq)[96]=c("Midnight");
row.names(d.freq)[1]=c("Midnight");
row.names(d.freq)[2:48]=c("")
row.names(d.freq)[50:95]=c("")
for(j in 1:7)
{
  st=(j-1)*96+1;en=st+95;
  d.freq[,j]=w.freq[st:en]
}
library(gplots)
rc <- colorRampPalette(c("cornsilk", "cyan2"), space = "rgb")(96)

h.map.count=heatmap.2(d.freq,colsep=c(1:7),rowsep=c(1:95),symbreaks=FALSE ,col=rc,RowSideColors=rc,offsetRow=0.3,
                      sepwidth=c(0.005,0.005), sepcolor="white", trace="none",
                      Rowv=F,Colv=F, scale="none", dendrogram="none",key=F, 
                      srtCol=0, adjCol=c(0.5,1),lwid=c(0.5,10.0),lhei = c(0.2,5.),margins=c(4,5.8),cexRow=1.0)

# similar plot for each 1 hour
# create a matrix 24 by 7

d1.freq=matrix(0,ncol=7,nrow=24)
colnames(d1.freq)=c("Mon","Tue","Wed","Thu","Fri","Sat","Sun")
row.lab1=format( seq.POSIXt(as.POSIXct(Sys.Date()), as.POSIXct(Sys.Date()+1), by = "hour"),"%H:%M",tz="GMT")
rownames(d1.freq)=row.lab1[-1];rownames(d1.freq)[12]=c("Noon");rownames(d1.freq)[24]=c("Midnight");
for(j in 1:7)
{
  for(i in 1:24)
    {
    st=(i-1)*4+1;en=st+4-1;
    d1.freq[i,j]=sum(d.freq[st:en,j])
    }
}

#############################################
############# Figure 1.3 ####################
#############################################

w1.freq=c(d1.freq);w1.ti=1:length(w1.freq)
plot(w1.ti,w1.freq,type="l",xaxt="n",main="Hourly Time Series Plot of Login Counts",xlab="Time Index: starts from SUN midnight till next SUN before midnight",ylab="Frequency: Averaged over # of weeks")
axis(1, xaxp=c(0, 168, 7), las=2)#dev.off()

#############################################
############# Figure 1.4 ####################
#############################################

rc1=colorRampPalette(c("cornsilk", "cyan2"), space = "rgb")(24)
h.map.count1=heatmap.2(d1.freq,colsep=c(1:7),symbreaks=FALSE ,col=rc1,RowSideColors=rc1,offsetRow=0.5,
                      sepwidth=c(0.0000,0.005), sepcolor="white", trace="none",
                      Rowv=F,Colv=F, scale="none", dendrogram="none",key=F, 
                      srtCol=45, adjCol=c(0.5,1),lwid=c(0.5,10.0),lhei = c(0.2,5.),margins=c(4,5.8),cexRow=1.0)


############################################################################
############## Part 3. Predictive Modeling #################################
############################################################################

# predictive modeling

#install.packages("rjson")
library(rjson)
setwd("C:/Users/Ashwini/Desktop/XYZ")
# JSON stores NaN as missing value but R parses as 4numeric, need to convert Nan to char, that
# can be done by repl by "NA" etc. and read the file. alternatively read csv file
udc=read.csv(file="modeling_data.csv",na.strings = c("","NA"))
colnames(udc)
udc$city=factor(udc$city)
udc$phone=factor(udc$phone)
udc$xyz_black_user=factor(udc$xyz_black_user)
head(udc)
udc[,3]=as.Date(udc[,3],format="%m/%d/%Y")
udc[,6]=as.Date(udc[,6],format="%m/%d/%Y")
# create response variable as if the user has taken a ride in last month, the last date is 2014/07/01

summary(udc)
# complete cases.
udc.c=udc[complete.cases(udc),];
udc.c$last_trip_date=as.numeric(udc.c$last_trip_date>"2014-06-01")

####################################################
################  Figure 3.1 #######################
####################################################
# box plot  before transforming the variables
udc.c.q0=udc.c[,c(2,4,5,10,11,12)]
boxplot(udc.c.q0)

# transform some variables that has high skewness,
udc.c.new=data.frame(udc.c);
udc.c.new$trips_in_first_30_days=log(1+udc.c$trips_in_first_30_days)
udc.c.new$avg_surge=log(udc.c$avg_surge)
udc.c.new$surge_pct=udc.c$surge_pct/100
udc.c.new$avg_dist=log(1+udc.c$avg_dist)
udc.c.new$weekday_pct=udc.c$weekday_pct/100


####################################################
################# Figure 3.2 #######################
####################################################

# box plot 
udc.c.q=udc.c.new[,c(2,4,5,10,11,12)]
boxplot(udc.c.q)

########## creating new variabes############
# 1. 1- weekday 
udc.c.new$weekend_pct=1-udc.c.new$weekday_pct
# surge_pct is highly skewed, can make category
udc.c.new$surge_pct_f=rep(0,length(udc.c.new$surge_pct))
udc.c.new$surge_pct_f[intersect(which(udc.c.new$surge_pct<=.10),which(udc.c.new$surge_pct>0))]=1
udc.c.new$surge_pct_f[intersect(which(udc.c.new$surge_pct<=.25),which(udc.c.new$surge_pct>0.1))]=2
udc.c.new$surge_pct_f[intersect(which(udc.c.new$surge_pct<=.50),which(udc.c.new$surge_pct>0.25))]=3
udc.c.new$surge_pct_f[intersect(which(udc.c.new$surge_pct<=.80),which(udc.c.new$surge_pct>0.5))]=4
udc.c.new$surge_pct_f[which(udc.c.new$surge_pct>0.8)]=5
udc.c.new$surge_pct_f=factor(udc.c.new$surge_pct_f);

# consider subset of data with only ordinal varibles
udc.c.q=udc.c.new[,c("trips_in_first_30_days","avg_rating_of_driver","avg_rating_by_driver","avg_surge","avg_dist","weekday_pct")]

# scale the variables first
# next check if the logit is linear in predictors
# avg_surge,avg_dist,surge_pct_f,weekday_pct

# 0. Trips in first 30 days
n1=10;
x=udc.c.new$trips_in_first_30_days
y=udc.c.new$last_trip_date
x1=seq(min(x),max(x),(max(x)-min(x))/n1);
l=length(x1);mp=rep(0,l-1);yp=mp;
for(i in 1:(l-1))
{
  mp[i]=(x1[i]+x1[i+1])/2
  yp[i]=mean(y[(x<x1[i+1])==(x>=x1[i])])
}
plot(mp,yp,main="last_trip_date(yes/no) by trips_in_first_30_days",ylab="average of yes/no",xlab="trips in first_30 days")

####################################################
################  Figure 3.3 #######################
####################################################
#1. Avg rating of driver
n1=20;
x=udc.c.new$avg_rating_of_driver
y=udc.c.new$last_trip_date
x1=seq(min(x),max(x),(max(x)-min(x))/n1);
l=length(x1);mp=rep(0,l-1);yp=mp;
for(i in 1:(l-1))
{
  mp[i]=(x1[i]+x1[i+1])/2
  yp[i]=mean(y[(x<x1[i+1])==(x>=x1[i])])
}
plot(mp,yp,main="last_trip_date(yes/no) by rating_of_driver",ylab="average of yes/no",xlab="Avg_rating_of_driver")

####################################################
################  Figure 3.4 #######################
####################################################
#2. Avg rating by driver
x=udc.c.new$avg_rating_by_driver
x1=seq(min(x),max(x),(max(x)-min(x))/n1);
l=length(x1);mp=rep(0,l-1);yp=mp;
for(i in 1:(l-1))
   {
     mp[i]=(x1[i]+x1[i+1])/2
     yp[i]=mean(y[(x<x1[i+1])==(x>=x1[i])])
   }
plot(mp,yp,main="last_trip_date(yes/no) by rating_by_driver",ylab="average of yes/no",xlab="Avg_rating_by_driver")

#3. Avg_surge
n1=20
x=udc.c.new$avg_surge;
x1=seq(min(x),max(x),(max(x)-min(x))/n1);
l=length(x1);mp=rep(0,l-1);yp=mp;
for(i in 1:(l-1))
{
  mp[i]=(x1[i]+x1[i+1])/2
  yp[i]=mean(y[(x<x1[i+1])==(x>=x1[i])])
}
plot(mp,yp,main="last_trip_date(yes/no) by avg_surge",ylab="average of yes/no",xlab="Avg_surge")

#4. Avg_dist
n1=20
x=udc.c.new$avg_dist;
x1=seq(min(x),max(x),(max(x)-min(x))/n1);
l=length(x1);mp=rep(0,l-1);yp=mp;
for(i in 1:(l-1))
  {
   mp[i]=(x1[i]+x1[i+1])/2
   yp[i]=mean(y[(x<x1[i+1])==(x>=x1[i])])
  }
plot(mp,yp,main="last_trip_date(yes/no) by avg_dist",ylab="average of yes/no",xlab="Avg_dist")

####################################################
################  Figure 3.5 #######################
####################################################
#5. surge_pct
n1=20
x=udc.c.new$surge_pct;
x1=seq(min(x),max(x),(max(x)-min(x))/n1);
l=length(x1);mp=rep(0,l-1);yp=mp;
for(i in 1:(l-1))
{
  mp[i]=(x1[i]+x1[i+1])/2
  yp[i]=mean(y[(x<x1[i+1])==(x>=x1[i])])
}
plot(mp,yp,main="last_trip_date(yes/no) by surge_pct",ylab="average of yes/no",xlab="surge_pct")

#5. weekday_pct
n1=10
x=udc.c.new$weekday_pct;
x1=seq(min(x),max(x),(max(x)-min(x))/n1);
l=length(x1);mp=rep(0,l-1);yp=mp;
for(i in 1:(l-1))
{
  mp[i]=(x1[i]+x1[i+1])/2
  yp[i]=mean(y[(x<x1[i+1])==(x>=x1[i])])
}
plot(mp,yp,main="last_trip_date(yes/no) by weekday_pct",ylab="average of yes/no",xlab="weekday_pct")

#############################################################
#####  create the dummy variables ###########################
#############################################################

# 1. City, 3 levels
c1=rep(0,nrow(udc.c.new));c1[udc.c.new$city=='Astapor']=1;
c2=rep(0,nrow(udc.c.new));c2[udc.c.new$city=='Winterfell']=1;
udc.c.new$City_AK=c1; udc.c.new$City_WK=c2;

#. 2. phone
p1=rep(0,nrow(udc.c.new));p1[udc.c.new$phone=='iPhone']=1;
udc.c.new$Phone_i=p1;

#. 3. surge_pct
s1=rep(0,nrow(udc.c.new));s1[udc.c.new$surge_pct_f==1]=1;
s2=rep(0,nrow(udc.c.new));s2[udc.c.new$surge_pct_f==2]=1;
s3=rep(0,nrow(udc.c.new));s3[udc.c.new$surge_pct_f==3]=1;
s4=rep(0,nrow(udc.c.new));s4[udc.c.new$surge_pct_f==4]=1;
s5=rep(0,nrow(udc.c.new));s5[udc.c.new$surge_pct_f==5]=1;
udc.c.new$surge_pct_10=s1;udc.c.new$surge_pct_20=s2;udc.c.new$surge_pct_30=s3;
udc.c.new$surge_pct_40=s4;udc.c.new$surge_pct_50=s5;

# 4. xyz_black
ub1=rep(0,nrow(udc.c.new));ub1[udc.c.new$xyz_black_user=='TRUE']=1;
udc.c.new$xyz_black=ub1;

################### now creating interaction terms #######################
#1. Avg_surge and xyz_black
udc.c.new$avg_surge_int_xyz_black=udc.c.new$avg_surge*udc.c.new$xyz_black;

#2. surge_pct and weekend_pct
udc.c.new$sur_10_int_wknd=udc.c.new$surge_pct_10*udc.c.new$weekend_pct;
udc.c.new$sur_20_int_wknd=udc.c.new$surge_pct_20*udc.c.new$weekend_pct;
udc.c.new$sur_30_int_wknd=udc.c.new$surge_pct_30*udc.c.new$weekend_pct;
udc.c.new$sur_40_int_wknd=udc.c.new$surge_pct_40*udc.c.new$weekend_pct;
udc.c.new$sur_50_int_wknd=udc.c.new$surge_pct_50*udc.c.new$weekend_pct;

#3. avg_dist and city
udc.c.new$avg_dist_int_city_AK=udc.c.new$avg_dist*udc.c.new$City_AK;
udc.c.new$avg_dist_int_city_WK=udc.c.new$avg_dist*udc.c.new$City_WK;

#4. trips_in_first 30_days and weekend 
udc.c.new$trp_30_days_int_wknd_pct=udc.c.new$trips_in_first_30_days*udc.c.new$weekend_pct;

#### fit the univariate logit models and check if the reltionship is linear and assess model significance
require(glmnet)

#5. trips_in_first 30_days and avg_dist
udc.c.new$trp_30_days_int_avg_dist=udc.c.new$trips_in_first_30_days*udc.c.new$avg_dist;

# check for multicollinearity
cor(udc.c.q)
eigen(cor(udc.c.q))$values


################ Create training and validation dataset#############
# take 2/3rd training and remaining 1/3rd as validation dataset
tr=sample(1:nrow(udc.c.new),floor(2/3*nrow(udc.c.new)),replace=FALSE);
udc.train=udc.c.new[tr,];
udc.val=udc.c.new[-c(tr),]

###################### Modeling #############################
# 0. intercept model
md.intrcpt=glm(last_trip_date~1,data=udc.train,family="binomial")
summary(md.intrcpt)

# 1. City
md.city=glm(last_trip_date~City_AK+City_WK,data=udc.train,family="binomial")
summary(md.city)

#. 2. phone
md.Ph=glm(last_trip_date~Phone_i,data=udc.train,family="binomial")
summary(md.Ph)

# 3. surge_pct
md.surge_p=glm(last_trip_date~surge_pct_10+surge_pct_20+surge_pct_30+surge_pct_40+surge_pct_50,data=udc.train,family="binomial")
summary(md.surge_p)

# 4. xyz_black
md.xyz_bl=glm(last_trip_date~xyz_black,data=udc.train,family="binomial")
summary(md.xyz_bl)

# 5. Avg_rating_of_driver
md.arod=glm(last_trip_date ~ avg_rating_of_driver, data = udc.train, family = "binomial")
summary(md.arod)

# 6. trips_in_first_30_days
md.trp3d=glm(last_trip_date ~ trips_in_first_30_days, data = udc.train, family = "binomial")
summary(md.trp3d)

# 7. avg_surge
md.avg_surge <- glm(last_trip_date ~ avg_surge, data = udc.train, family = "binomial")
summary(md.avg_surge)

# 8. Avg_dist
md.ad=glm(last_trip_date ~ avg_dist, data = udc.train, family = "binomial")
summary(md.ad)

# 9. avg_rating_by_driver
md.arbd=glm(last_trip_date ~ avg_rating_by_driver, data = udc.train, family = "binomial")
summary(md.arbd)

# 10. Weekday_pct
md.wp=glm(last_trip_date ~weekday_pct, data = udc.train, family = "binomial")
summary(md.wp)

# full  model.0
md.all=glm(last_trip_date~City_AK+City_WK+trips_in_first_30_days+avg_rating_of_driver+avg_rating_by_driver+avg_surge+Phone_i+surge_pct_10+surge_pct_20+surge_pct_30+surge_pct_40+surge_pct_50+xyz_black+weekday_pct+avg_dist,data=udc.train,family="binomial")
summary(md.all)

# full  model.1
md.all1=glm(last_trip_date~City_AK+City_WK+trips_in_first_30_days+avg_rating_by_driver+avg_surge+Phone_i+surge_pct_10+surge_pct_20+surge_pct_30+surge_pct_40+surge_pct_50+xyz_black+weekday_pct+avg_dist,data=udc.train,family="binomial")
summary(md.all1)

# full  model.2
md.all2=glm(last_trip_date~City_AK+City_WK+trips_in_first_30_days+avg_rating_by_driver+avg_surge+Phone_i+surge_pct_10+surge_pct_20+surge_pct_30+surge_pct_40+surge_pct_50+xyz_black+avg_dist,data=udc.train,family="binomial")
summary(md.all2)

# full  model.21
md.all2.1=glm(last_trip_date~City_AK+City_WK+trips_in_first_30_days+avg_rating_by_driver+avg_surge+Phone_i+surge_pct_10+surge_pct_20+surge_pct_30+surge_pct_40+surge_pct_50+xyz_black,data=udc.train,family="binomial")
summary(md.all2.1)

# overall sig of model
with(md.all, pchisq(null.deviance - deviance, df.null - df.residual, lower.tail = FALSE))
#logLik(md.all)


# now include the interctions one by one and check the model significance.
#1. Avg_surge and xyz_black
md.all3=glm(last_trip_date~City_AK+City_WK+trips_in_first_30_days+avg_rating_of_driver+
              avg_rating_by_driver+avg_surge+Phone_i+surge_pct_10+surge_pct_20+surge_pct_30+
              surge_pct_40+surge_pct_50+xyz_black+weekday_pct+
              avg_dist+avg_surge_int_xyz_black,data=udc.train,family="binomial")
t3=-2*(logLik(md.all)-logLik(md.all3));
pvalue3=1-pchisq(t3[1],1);pvalue3;

#2. surge_pct and weekend_pct
md.all4=glm(last_trip_date~City_AK+City_WK+trips_in_first_30_days+avg_rating_of_driver+
              avg_rating_by_driver+avg_surge+Phone_i+surge_pct_10+surge_pct_20+surge_pct_30+
              surge_pct_40+surge_pct_50+xyz_black+weekday_pct+
              avg_dist+sur_10_int_wknd+sur_20_int_wknd+sur_30_int_wknd+sur_40_int_wknd+
              sur_50_int_wknd,data=udc.train,family="binomial")
t4=-2*(logLik(md.all)-logLik(md.all4));
pvalue4=1-pchisq(t4[1],5);pvalue4;

#3. avg_dist and city
md.all5=glm(last_trip_date~City_AK+City_WK+trips_in_first_30_days+avg_rating_of_driver+
              avg_rating_by_driver+avg_surge+Phone_i+surge_pct_10+surge_pct_20+surge_pct_30+
              surge_pct_40+surge_pct_50+xyz_black+weekday_pct+
              avg_dist+avg_dist_int_city_AK+avg_dist_int_city_WK,data=udc.train,family="binomial")
t5=-2*(logLik(md.all)-logLik(md.all5));
pvalue5=1-pchisq(t5[1],2);pvalue5;

#4. trips_in_first 30_days and weekend 
md.all6=glm(last_trip_date~City_AK+City_WK+trips_in_first_30_days+avg_rating_of_driver+
              avg_rating_by_driver+avg_surge+Phone_i+surge_pct_10+surge_pct_20+surge_pct_30+
              surge_pct_40+surge_pct_50+xyz_black+weekday_pct+
              avg_dist+trp_30_days_int_wknd_pct,data=udc.train,family="binomial")
# Likelihood test of significance,
t6=-2*(logLik(md.all)-logLik(md.all6));
pvalue6=1-pchisq(t6[1],1);pvalue6; #pvalue=0.48

#5. trips_in_first 30_days and avg_dist
md.all7=glm(last_trip_date~City_AK+City_WK+trips_in_first_30_days+avg_rating_of_driver+
              avg_rating_by_driver+avg_surge+Phone_i+surge_pct_10+surge_pct_20+surge_pct_30+
              surge_pct_40+surge_pct_50+xyz_black+weekday_pct+
              avg_dist+trp_30_days_int_avg_dist,data=udc.train,family="binomial")
t7=-2*(logLik(md.all)-logLik(md.all7));
pvalue7=1-pchisq(t7[1],1);pvalue7;

# Include all the interaction in the model whose p-value of interaction coeff. is at least 0.25 
# this way we include all the interaction.

md.all8=glm(last_trip_date~City_AK+City_WK+trips_in_first_30_days+avg_rating_of_driver+
              avg_rating_by_driver+avg_surge+Phone_i+surge_pct_10+surge_pct_20+surge_pct_30+
              surge_pct_40+surge_pct_50+xyz_black+weekday_pct+
              avg_dist+avg_surge_int_xyz_black+trp_30_days_int_avg_dist+sur_10_int_wknd
            +sur_20_int_wknd+sur_30_int_wknd+sur_40_int_wknd+sur_50_int_wknd
            +avg_dist_int_city_AK+avg_dist_int_city_WK,data=udc.train,family="binomial")
t8=-2*(logLik(md.all)-logLik(md.all8));
pvalue8=1-pchisq(t8[1],1);pvalue8;

summary(md.all8)

# interaction  term avg_dist_int_city_AK and avg_dist_int_city_WK not significannt, therefore drop from model
md.all9=glm(last_trip_date~City_AK+City_WK+trips_in_first_30_days+avg_rating_of_driver+
              avg_rating_by_driver+avg_surge+Phone_i+surge_pct_10+surge_pct_20+surge_pct_30+
              surge_pct_40+surge_pct_50+xyz_black+weekday_pct+
              avg_dist+avg_surge_int_xyz_black+trp_30_days_int_avg_dist+sur_10_int_wknd
            +sur_20_int_wknd+sur_30_int_wknd+sur_40_int_wknd+sur_50_int_wknd
            ,data=udc.train,family="binomial")
t9=-2*(logLik(md.all)-logLik(md.all9));
pvalue9=1-pchisq(t9[1],1);pvalue9;

summary(md.all9)

# the main effect term avg_dist turns out to be insignificant, therefore remove the interaction term 
# that has avg_dist in it and remodel it
md.all11=glm(last_trip_date~City_AK+City_WK+trips_in_first_30_days+avg_rating_of_driver+
               avg_rating_by_driver+avg_surge+Phone_i+surge_pct_10+surge_pct_20+surge_pct_30+
               surge_pct_40+surge_pct_50+xyz_black+weekday_pct+
               avg_dist+avg_surge_int_xyz_black+sur_10_int_wknd
             +sur_20_int_wknd+sur_30_int_wknd+sur_40_int_wknd+sur_50_int_wknd
             ,data=udc.train,family="binomial")
t11=-2*(logLik(md.all)-logLik(md.all11));
pvalue11=1-pchisq(t11[1],1);pvalue11;

summary(md.all11)

# Note that suurge_pct_int_wknd is significant for only sur_20_int_wknd, so dropping this term, lets see how much change in loglik
md.all12=glm(last_trip_date~City_AK+City_WK+trips_in_first_30_days+avg_rating_of_driver+
               avg_rating_by_driver+avg_surge+Phone_i+surge_pct_10+surge_pct_20+surge_pct_30+
               surge_pct_40+surge_pct_50+xyz_black+weekday_pct+
               avg_dist+avg_surge_int_xyz_black
               ,data=udc.train,family="binomial")
t12=-2*(logLik(md.all11)-logLik(md.all12));
pvalue12=1-pchisq(t12[1],5);pvalue12;

summary(md.all12)

# the above model has all the coefficients statistically significant, therefore use this model for prediction
md.final=glm(last_trip_date~City_AK+City_WK+trips_in_first_30_days+avg_rating_by_driver+
               avg_surge+Phone_i+surge_pct_10+surge_pct_20+surge_pct_30+
               surge_pct_40+surge_pct_50+xyz_black+
               avg_surge_int_xyz_black
             ,data=udc.train,family="binomial")

#######################################################
########### Making predictions on validation data#####
#######################################################
tr=sample(1:nrow(udc.c.new),floor(2/3*nrow(udc.c.new)),replace=FALSE);
udc.train=udc.c.new[tr,];
udc.val=udc.c.new[-c(tr),]

# the above model has all the coefficients statistically significant, therefore use this model for prediction
md.final=glm(last_trip_date~City_AK+City_WK+trips_in_first_30_days+avg_rating_by_driver+
               avg_surge+Phone_i+surge_pct_10+surge_pct_20+surge_pct_30+
               surge_pct_40+surge_pct_50+xyz_black+
               avg_surge_int_xyz_black
             ,data=udc.train,family="binomial")

x.test=udc.val;x.test$last_trip_date=c();
y.test=udc.val$last_trip_date;

## predict using md.all11
y1=predict(md.final, newdata=x.test, type="response"); y.pred = round(y1)
tbl = table(y.test,y.pred); err=1-sum(diag(tbl))/sum(tbl)
err;
